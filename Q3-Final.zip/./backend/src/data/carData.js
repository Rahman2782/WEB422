let cars = [
  { id: 1, make: "Toyota", model: "Corolla", year: 2019, price: 15000 },
  { id: 2, make: "Honda", model: "Civic", year: 2018, price: 14000 },
];

module.exports = cars;
